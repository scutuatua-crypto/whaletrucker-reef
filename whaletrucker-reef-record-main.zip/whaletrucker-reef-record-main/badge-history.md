
---

## 🎖️ badge-history.md
```markdown
# 🎖️ Badge History

- 🌊 Patch‑1: Mail Flow anchored  
- 🌊 Patch‑2: Recovery Ritual mapped  
- 🌊 Patch‑3: Reef Compass created  
- 🌊 Patch‑4: Governance chart minted  

