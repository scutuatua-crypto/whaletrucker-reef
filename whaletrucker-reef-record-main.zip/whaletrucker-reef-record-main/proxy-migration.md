
---

## 🔗 proxy-migration.md
```markdown
# 🔗 Proxy Migration Rituals

```mermaid
flowchart TD
    A[Relay Chain Multisig] --> B[Proxy Type Translation]
    B --> C[Deposit Recalculation]
    C --> D[Asset Hub Proxy]

