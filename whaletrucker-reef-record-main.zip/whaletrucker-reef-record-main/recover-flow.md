
---

## 🛠️ recover-flow.md
```markdown
# 🛠️ Recovery Flow

```mermaid
flowchart TD
    A[Error Signal] --> B[Retry Ritual]
    B --> C[Archive Scar]
    C --> D[Badge Minted]
