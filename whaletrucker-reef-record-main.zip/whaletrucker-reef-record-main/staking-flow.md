
---

## 🌱 staking-flow.md
```markdown
# 🌱 Staking Flow

```mermaid
flowchart TD
    A[Delegator] --> B[Validator]
    B --> C[Rewards]
    C --> D[Archive Badge]

