
---

## 🌊 reef-flow.md
```markdown
# 🌊 Reef Flow

```mermaid
flowchart TD
    A[GitHub Identity] --> B[ImprovMX Alias]
    B --> C[Cloudflare Routing]
    C --> D[Ritual Logs]

