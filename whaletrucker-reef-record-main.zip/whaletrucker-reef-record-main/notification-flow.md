
---

## 🔔 notification-flow.md
```markdown
# 🔔 Notification Flow

```mermaid
flowchart TD
    A1[Gmail Signal] --> B1[Tag + Quiet Mode]
    A2[Notion Update] --> B1
    A3[Basecamp Ping] --> B1
    B1 --> C1[Archived Coral]
    C1 --> D1[splash.log Entry]
    D1 --> E1[Badge Minted]

