
---

## 🗳️ governance-flow.md
```markdown
# 🗳️ Governance Flow

```mermaid
flowchart TD
    A[Proposal Submitted] --> B[Community Vote]
    B --> C[Decision Logged]
    C --> D[Badge Minted]

